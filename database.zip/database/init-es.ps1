#Requires -Version 5.1
<#
.SYNOPSIS
  初始化 Elasticsearch：创建活动索引、部署 ELSER 模型（语义检索 / 推荐）

.DESCRIPTION
  对应《技术选型.md》第 1/2 部分：
  - 索引 campus_activities：IK 分词（BM25 关键词通路）+ dense_vector 384 维（kNN 向量通路）
  - 部署 .elser_model_2 供后续向量化与 text_expansion 使用

.EXAMPLE
  .\init-es.ps1
  等待 ES 就绪后创建索引并部署 ELSER

.EXAMPLE
  .\init-es.ps1 -SkipElser
  仅创建索引，跳过 ELSER（首次下载模型较慢，可稍后单独部署）

.EXAMPLE
  .\init-es.ps1 -ForceRecreateIndex
  删除并重建 campus_activities 索引
#>
[CmdletBinding()]
param(
    [string]$EsHost = "127.0.0.1",
    [int]$EsPort = 9200,
    [string]$IndexName = "campus_activities",
    [switch]$SkipElser,
    [switch]$ForceRecreateIndex,
    [int]$HealthWaitSeconds = 180,
    [switch]$SeedDocuments
)

$ErrorActionPreference = "Stop"
$ScriptDir = $PSScriptRoot
$IndexFile = Join-Path $ScriptDir "elasticsearch\activity-index.json"

function Write-Step($Message) {
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Write-Ok($Message) {
    Write-Host "[OK] $Message" -ForegroundColor Green
}

function Write-Warn($Message) {
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-Err($Message) {
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

function Get-EsBaseUrl {
    return "http://${EsHost}:${EsPort}"
}

function Test-ElasticsearchConnection {
    try {
        $response = Invoke-RestMethod -Uri "$(Get-EsBaseUrl)/" -Method Get -TimeoutSec 5
        return ($null -ne $response.version.number)
    }
    catch {
        return $false
    }
}

function Wait-ForElasticsearch {
    Write-Step "等待 Elasticsearch 就绪 (最多 ${HealthWaitSeconds}s)"
    $deadline = (Get-Date).AddSeconds($HealthWaitSeconds)
    while ((Get-Date) -lt $deadline) {
        try {
            $healthUri = "$(Get-EsBaseUrl)/_cluster/health?wait_for_status=yellow" + '&timeout=30s'
            $health = Invoke-RestMethod -Uri $healthUri -Method Get -TimeoutSec 35
            if ($health.status -in @("yellow", "green")) {
                Write-Ok "集群状态: $($health.status) (节点 $($health.number_of_nodes))"
                return $true
            }
        }
        catch {
            # 容器尚在启动
        }
        Start-Sleep -Seconds 3
    }
    throw "Elasticsearch 在 ${HealthWaitSeconds}s 内未就绪，请检查 Docker 容器 campus-elasticsearch"
}

function Test-IndexExists {
    param([string]$Name)
    try {
        Invoke-RestMethod -Uri "$(Get-EsBaseUrl)/$Name" -Method Get -TimeoutSec 10 | Out-Null
        return $true
    }
    catch {
        if ($_.Exception.Response -and $_.Exception.Response.StatusCode.value__ -eq 404) {
            return $false
        }
        throw
    }
}

function Initialize-ActivityIndex {
    if (-not (Test-Path $IndexFile)) {
        throw "未找到索引定义: $IndexFile"
    }

    $exists = Test-IndexExists -Name $IndexName
    if ($exists -and -not $ForceRecreateIndex) {
        Write-Ok "索引 '$IndexName' 已存在，跳过创建（使用 -ForceRecreateIndex 可重建）"
        return
    }

    if ($exists -and $ForceRecreateIndex) {
        Write-Warn "删除现有索引 '$IndexName'"
        Invoke-RestMethod -Uri "$(Get-EsBaseUrl)/$IndexName" -Method Delete -TimeoutSec 30 | Out-Null
    }

    Write-Step "创建索引 '$IndexName'（IK 分词 + dense_vector 384）"
    $body = Get-Content -Path $IndexFile -Raw -Encoding UTF8
    $result = Invoke-RestMethod -Uri "$(Get-EsBaseUrl)/$IndexName" -Method Put -Body $body -ContentType "application/json; charset=utf-8" -TimeoutSec 60
    if (-not $result.acknowledged) {
        throw "创建索引失败: $($result | ConvertTo-Json -Compress)"
    }
    Write-Ok "索引 '$IndexName' 创建成功"
}

function Deploy-ElserModel {
    Write-Step "部署 ELSER 模型 (.elser_model_2)"
    Write-Host "  首次部署会从 Elastic 下载模型，可能需要 5-15 分钟，请耐心等待..." -ForegroundColor Gray

    $deployUri = "$(Get-EsBaseUrl)/_ml/trained_models/.elser_model_2/_deploy?wait_for=started" + '&timeout=30m'
    try {
        $result = Invoke-RestMethod -Uri $deployUri -Method Put -TimeoutSec 1800
        Write-Ok "ELSER 部署请求已接受: $($result.assignment.task_type)"
    }
    catch {
        $detail = $_.Exception.Message
        if ($detail -match "already") {
            Write-Ok "ELSER 模型已在运行"
            return
        }
        throw "ELSER 部署失败: $detail`n提示: 确保 xpack.ml.enabled=true 且容器内存 >= 2GB"
    }

    $deadline = (Get-Date).AddMinutes(20)
    while ((Get-Date) -lt $deadline) {
        try {
            $stats = Invoke-RestMethod -Uri "$(Get-EsBaseUrl)/_ml/trained_models/.elser_model_2/_stats" -Method Get -TimeoutSec 30
            $state = $stats.trained_model_configs[0].deployment_stats.allocation_status.state
            if ($state -eq "started") {
                Write-Ok "ELSER 模型已启动 (state=started)"
                return
            }
            Write-Host "  当前状态: $state ..." -ForegroundColor Gray
        }
        catch {
            Write-Host "  等待模型启动..." -ForegroundColor Gray
        }
        Start-Sleep -Seconds 10
    }
    Write-Warn "ELSER 仍在启动中，可通过 Kibana Dev Tools 或 GET _ml/trained_models/.elser_model_2/_stats 查看进度"
}

function Show-Summary {
    Write-Host "`n--- Elasticsearch 环境摘要 ---" -ForegroundColor Magenta
    Write-Host "  REST API : $(Get-EsBaseUrl)" -ForegroundColor White
    Write-Host "  索引     : $IndexName" -ForegroundColor White
    Write-Host "  Kibana   : http://${EsHost}:5601" -ForegroundColor White
    Write-Host "  验证命令 : curl $(Get-EsBaseUrl)/campus_activities/_mapping" -ForegroundColor White
    Write-Host "  后端配置 : spring.elasticsearch.uris=$(Get-EsBaseUrl)" -ForegroundColor White
}

try {
    Write-Host "校园活动平台 - Elasticsearch 初始化" -ForegroundColor Magenta

    if (-not (Test-ElasticsearchConnection)) {
        throw @(
            "无法连接 $(Get-EsBaseUrl)",
            "请先启动: cd database; docker compose up -d elasticsearch",
            "或启动全部: docker compose up -d"
        ) -join "`n"
    }

    Wait-ForElasticsearch | Out-Null
    Initialize-ActivityIndex

    if ($SeedDocuments) {
        Write-Step "导入示例活动文档（bulk seed）"
        $seedScript = Join-Path $ScriptDir "index-seed.ps1"
        & $seedScript -EsHost $EsHost -EsPort $EsPort -IndexName $IndexName
        if ($LASTEXITCODE -ne 0) {
            throw "示例数据导入失败"
        }
    }

    if (-not $SkipElser) {
        Deploy-ElserModel
    }
    else {
        Write-Warn "已跳过 ELSER 部署（-SkipElser）。后续可不带 -SkipElser 重新执行 init-es.ps1"
    }

    Show-Summary
    Write-Ok "Elasticsearch 初始化完成"
}
catch {
    Write-Err $_.Exception.Message
    exit 1
}
