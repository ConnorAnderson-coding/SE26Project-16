# 数据库启动说明

## 使用 Docker Compose（推荐）

```bash
cd database
docker compose up -d
```

服务信息：
- MySQL: `localhost:3306`，数据库 `campus_activity`，用户 `campus` / `campus123`
- Redis: `localhost:6379`（后端 Spring Cache 缓存，key 前缀 `campus:`）
- Elasticsearch: `localhost:9200`（语义检索 / 活动推荐，索引 `campus_activities`）
- Kibana: `localhost:5601`（ES 调试与 Dev Tools）

首次启动会自动执行 `schema.sql` 和 `seed.sql`。

### Elasticsearch（检索 & 推荐）

对应《技术选型.md》第 1/2 部分：BM25 关键词检索（IK 分词）+ ELSER 向量检索（`dense_vector` 384 维）+ 后续 RRF 融合。

**内存要求**：建议 Docker Desktop 为 Elasticsearch 分配 **≥ 2GB** 内存（启用 ML / ELSER 时）。

仅启动 ES（含 IK 分词插件的自定义镜像）：

```powershell
cd database
docker compose up -d --build elasticsearch
```

初始化索引并部署 ELSER 模型（首次部署会下载模型，约 5–15 分钟）：

```powershell
cd database
.\init-es.ps1
# 仅建索引、跳过 ELSER：.\init-es.ps1 -SkipElser
```

一键建库 + 启动 ES + 初始化索引：

```powershell
cd database
.\setup-local.ps1 -InitElasticsearch
# 跳过 ELSER 部署：.\setup-local.ps1 -InitElasticsearch -SkipElser
```

验证：

```powershell
curl http://localhost:9200
curl http://localhost:9200/campus_activities/_count
```

### 索引构建（MySQL -> ES）

**方式 A：脚本 bulk 导入示例数据（无需后端）**

```powershell
cd database
.\init-es.ps1 -SkipElser -SeedDocuments
# 或单独执行
.\index-seed.ps1
```

**方式 B：后端全量重建（从 MySQL 同步）**

启用 Elasticsearch profile 并启动后端：

```powershell
cd backend
$env:SPRING_PROFILES_ACTIVE="elasticsearch"
.\mvnw.cmd spring-boot:run
```

> 默认配置下 ES 是关闭的（避免未启动 ES 时后端无法启动）。需要索引功能时请加 `elasticsearch` profile，不要只设 `ES_ENABLED=true`。

```powershell
# 管理员登录获取 token 后
curl -X POST http://localhost:8080/api/v1/search/index/rebuild `
  -H "Authorization: Bearer <admin_token>"
```

演示账号 `admin001 / 123456`。

新建/更新/删除活动时会自动同步到 ES（非 draft 状态）。

### Kibana 分词演示

```powershell
docker compose up -d kibana
```

打开 http://localhost:5601/app/dev_tools ，按 `database/elasticsearch/kibana-analyze-demo.md` 中的请求逐步执行，对比 `ik_max_analyzer` 与 `ik_smart_analyzer` 的分词差异。

后端预留配置（`application.properties`）：

```properties
spring.elasticsearch.uris=http://localhost:9200
ES_ACTIVITIES_INDEX=campus_activities
```

### 中文乱码排查

若前端从后端获取的中文显示乱码（前端硬编码中文正常），常见有两类原因：

**1. 数据库初始化字符集错误（全部接口乱码）**

MySQL 首次导入 `seed.sql` 时客户端不是 UTF-8，中文被双重编码写入数据库。

修复（会清空数据库）：

```bash
cd database
docker compose down -v
docker compose up -d
```

**2. Redis 缓存了修复前的旧数据（仅部分接口乱码）**

个人中心（`/users/me`）、活动详情、签到页活动选项等走 Redis 缓存的接口仍乱码，而登录、活动列表正常——说明 **数据库已正确，但 Redis 里还有修复前的脏缓存**。

若本机已安装 Redis 并占用 `6379`，后端可能连到本机 Redis 而非 Docker 容器，执行 `docker exec campus-redis redis-cli FLUSHDB` 无效。建议关闭本机 Redis，仅使用 Docker 提供的 Redis。

修复步骤：

```powershell
# 清空本机 Redis 中的项目缓存（若本机 Redis 在 6379）
redis-cli -p 6379 FLUSHALL

cd database
docker compose up -d
```

然后 **重启后端**，浏览器 **退出登录再重新登录**（清除 localStorage 中的旧用户信息）。

项目已在 Docker MySQL 启动参数中强制 `utf8mb4`，并在 `schema.sql` / `seed.sql` 开头执行 `SET NAMES utf8mb4`；后端 JDBC URL 也指定了 `characterEncoding=UTF-8`。

仅启动 Redis：

```bash
cd database
docker compose up -d redis
```

## 手动建库

1. 创建数据库并执行 `schema.sql`
2. 执行 `seed.sql` 导入示例数据

## 后端启动

**请先确保 Redis 已运行**（后端使用 Spring Cache + Redis 缓存活动详情、热门列表等）。

```bash
cd backend
./mvnw spring-boot:run
```

默认连接 `localhost:3306/campus_activity`，Redis `localhost:6379`。

## 前端启动

```bash
cd campus-activity
npm install
npm run dev
```

开发环境通过 Vite 代理将 `/api` 转发到 `http://localhost:8080`。

## 演示账号

| 账号 | 密码 | 角色 |
|------|------|------|
| 524030910001 | 123456 | 学生 |
| 524030910002 | 123456 | 学生 |
| T001 | 123456 | 教师 |
| admin001 | 123456 | 管理员 |
